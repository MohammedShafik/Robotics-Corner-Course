#!/bin/bash


mkdir dip
echo "dip folder created successfully"
echo "List for current folder:"
ls
echo "---------------------------------------------------------"
cd dip
touch FL_1.txt FL_2.txt FL_3.txt FL_4.txt FL_5.txt
echo "Five text files created inside the *dip* folder:"
ls
cd ..

